<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>update_category</title>
      <!--Custom Font-->
      <link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
   </head>
   <body>
      <div class="panel panel-default">
         <div class="panel-heading">
            <h1>Update Vehicle Category</h1>
         </div>
         <div class="panel-body">
            <div class="col-md-12">
               <div class="form-group">
                  <label>Category Name</label>
                  <input type="text" class="form-control" placeholder="GA8KH-8690" value="" id="catename" name="catename" required>
               </div>
               <button type="submit" class="btn btn-success" name="update-category">Make Changes</button>
            </div>
            </form>
         </div>
      </div>
      </div>
      </script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>		
   </body>
</html>